#!/bin/bash

TASK_FILE="tasks.txt"

# Ensure the task file exists
touch "$TASK_FILE"

# Function to create a new task
create_task() {
  echo "Adding a new task..."
  read -p "Task Title (mandatory): " title
  while [[ -z "$title" ]]; do
    echo "Title is required."
    read -p "Task Title (mandatory): " title
  done

  read -p "Task Description (optional): " description
  read -p "Task Location (optional): " location
  read -p "Due Date & Time (required, format YYYY-MM-DD HH:MM): " due_date
  while [[ ! "$due_date" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}\ [0-9]{2}:[0-9]{2}$ ]]; do
    echo "Incorrect date format. Please use YYYY-MM-DD HH:MM."
    read -p "Due Date & Time (required, format YYYY-MM-DD HH:MM): " due_date
  done

  completion_status="false"
  task_id=$(date +%s%N)

  echo "$task_id|$title|$description|$location|$due_date|$completion_status" >> "$TASK_FILE"
  echo "Task successfully added."
}

# Function to update an existing task
update_task() {
  read -p "Enter the Task ID to update: " id
  task=$(grep "^$id|" "$TASK_FILE")
  if [[ -z "$task" ]]; then
    echo "Task ID not found." >&2
    return
  fi

  read -p "New Title (leave blank to keep current): " title
  read -p "New Description (leave blank to keep current): " description
  read -p "New Location (leave blank to keep current): " location
  read -p "New Due Date & Time (format YYYY-MM-DD HH:MM, leave blank to keep current): " due_date
  read -p "Completion Status (true/false, leave blank to keep current): " completion_status

  old_IFS=$IFS
  IFS="|"
  read -r old_id old_title old_description old_location old_due_date old_completion_status <<< "$task"
  IFS=$old_IFS

  title=${title:-$old_title}
  description=${description:-$old_description}
  location=${location:-$old_location}
  due_date=${due_date:-$old_due_date}
  completion_status=${completion_status:-$old_completion_status}

  sed -i '' "s/^$id|.*/$id|$title|$description|$location|$due_date|$completion_status/" "$TASK_FILE"
  echo "Task updated successfully."
}

# Function to delete a task
delete_task() {
  read -p "Enter the Task ID to delete: " id
  sed -i '' "/^$id|/d" "$TASK_FILE"
  echo "Task deleted successfully."
}

# Function to show a task's details
show_task() {
  read -p "Enter the Task ID to show: " id
  task=$(grep "^$id|" "$TASK_FILE")
  if [[ -z "$task" ]]; then
    echo "Task ID not found." >&2
    return
  fi

  IFS="|"
  read -r id title description location due_date completion_status <<< "$task"
  IFS=$old_IFS
  echo "ID: $id"
  echo "Title: $title"
  echo "Description: $description"
  echo "Location: $location"
  echo "Due Date: $due_date"
  echo "Completion Status: $completion_status"
}

# Function to list tasks for a specific date
list_tasks() {
  read -p "Enter date (format YYYY-MM-DD): " date
  completed_tasks=$(grep "|$date" "$TASK_FILE" | grep "|true$")
  uncompleted_tasks=$(grep "|$date" "$TASK_FILE" | grep "|false$")

  echo "Completed tasks on $date:"
  echo "$completed_tasks" | while IFS="|" read -r id title description location due_date completion_status; do
    echo "ID: $id, Title: $title, Description: $description, Location: $location, Due Date: $due_date"
  done

  echo "Uncompleted tasks on $date:"
  echo "$uncompleted_tasks" | while IFS="|" read -r id title description location due_date completion_status; do
    echo "ID: $id, Title: $title, Description: $description, Location: $location, Due Date: $due_date"
  done
}

# Function to search for a task by title
search_task() {
  read -p "Enter title to search: " title
  tasks=$(grep "|$title|" "$TASK_FILE")
  if [[ -z "$tasks" ]]; then
    echo "No tasks found with the specified title."
    return
  fi

  echo "Tasks with the title '$title':"
  echo "$tasks" | while IFS="|" read -r id title description location due_date completion_status; do
    echo "ID: $id, Title: $title, Description: $description, Location: $location, Due Date: $due_date, Completion Status: $completion_status"
  done
}

# Function to show today's tasks
show_today_tasks() {
  today=$(date +%Y-%m-%d)
  completed_today=$(grep "|$today" "$TASK_FILE" | grep "|true$")
  uncompleted_today=$(grep "|$today" "$TASK_FILE" | grep "|false$")

  echo "Today's completed tasks:"
  echo "$completed_today" | while IFS="|" read -r id title description location due_date completion_status; do
    echo "ID: $id, Title: $title, Description: $description, Location: $location, Due Date: $due_date"
  done

  echo "Today's uncompleted tasks:"
  echo "$uncompleted_today" | while IFS="|" read -r id title description location due_date completion_status; do
    echo "ID: $id, Title: $title, Description: $description, Location: $location, Due Date: $due_date"
  done
}

# Main script logic
case "$1" in
  create)
    create_task
    ;;
  update)
    update_task
    ;;
  delete)
    delete_task
    ;;
  show)
    show_task
    ;;
  list)
    list_tasks
    ;;
  search)
    search_task
    ;;
  *)
    show_today_tasks
    ;;
esac
